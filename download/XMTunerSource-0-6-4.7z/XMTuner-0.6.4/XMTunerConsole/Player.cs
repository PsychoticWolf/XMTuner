﻿/*
 * XMTuner: Copyright (C) 2009-2012 Chris Crews and Curtis M. Kularski.
 * 
 * This file is part of XMTuner.

 * XMTuner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * XMTuner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with XMTuner.  If not, see <http://www.gnu.org/licenses/>.
 */

using System;
using System.Windows.Forms;
using System.Drawing;
using System.Reflection;

namespace XMTuner
{
    public partial class Form1 : Form
    {
        int playerNum;
        int p;
        int sleepPlayerNum = 0;

        #region Player
        private void updateNowPlayingData(Boolean useDefault, Boolean isLoading, Int32 num)
        {
            if (useDefault == true || isLoading == true)
            {
                pLogoBox.ImageLocation = "";
                showLogo();
                syncStatusLabel();
                pLabel1.Text = ""; //"Channel:";
                pLabel2.Text = ""; //"Title:";
                pLabel3.Text = ""; //"Artist:";
                pLabel4.Text = ""; //"Album:";
                pLabel5.Text = "";
                pLabel6.Text = "";

                if (isLoading == true && num > 0)
                {
                    XMChannel npChannel = self.Find(num);
                    if (npChannel.num != 0)
                    {
                        pLabel1.Text = npChannel.ToString();
                        pLabel2.Text = "Loading...";
                    }
                }

                playerPanel.Refresh();
            }
            else
            {
                if (num == 0)
                {
                    num = playerNum;
                }

                XMChannel npChannel = self.Find(num);
                if (npChannel.num == 0) { return; }

                if (pStatusLabel.Visible == true)
                {
                    syncStatusLabel();
                }

                if (npChannel.logo != null)
                {
                    if (pLogoBox.ImageLocation.Equals(""))
                    {
                        pLogoBox.ClientSize = new Size(128, 50);
                        pLogoBox.ImageLocation = npChannel.logo;
                    }
                }
                pLabel1.Text = npChannel.ToString();
                pLabel2.Text = npChannel.song;
                pLabel3.Text = npChannel.artist;
                //pLabel5 is Player status (Handled in axWindowsMediaPlayer1_StatusChange)
                pLabel6.Text = axWindowsMediaPlayer1.Ctlcontrols.currentPositionString; //pLabel6 is Player timer

                //pLabel4: Tri-mode Artist/Program Now/Next Text
                if (p <= 5)
                {
                    if (npChannel.album == null || npChannel.album.Equals("")) { p = 5; p++; return; }
                    pLabel4.Text = npChannel.album;
                }
                else if (p <= 10 && p > 5)
                {
                    String[] program = self.getCurrentProgram(npChannel.programData);
                    if (program == null) { p = 10; p++; return; }
                    pLabel4.Text = "Now: " + program[2];
                }
                else if (p > 10)
                {
                    String[] nextProgram = self.getNextProgram(npChannel.programData);
                    if (nextProgram == null) { p = 0; p++; return; }
                    pLabel4.Text = "Next: " + DateTime.Parse(nextProgram[4]).ToShortTimeString() + ": " + nextProgram[2];
                    if (p >= 15) { p = 0; }
                }
                p++;
            }
        }

        private void syncStatusLabel()
        {
            pStatusLabel.Visible = true;
            if (loggedIn == false)
            {
                if (isConfigurationLoaded == false)
                {
                    pStatusLabel.Text = "XMTuner needs to be configured before you can begin...";
                }
                else
                {
                    pStatusLabel.Text = "Log in to begin...";
                }
            }
            else
            {
                if (playerNum != 0)
                {
                    pStatusLabel.Text = "";
                    pStatusLabel.Visible = false;
                }
                else
                {
                    pStatusLabel.Text = "Select a channel...";
                }
            }
        }

        private void play(int num)
        {
            updateNowPlayingData(true, true, num);

            String url = self.play(num, "high");
            if (url == null)
            {
                pLabel2.Text = "Error fetching stream";
                pLabel3.Text = "Check log for more details...";
                pStatusLabel.Text = "";
                return;
            }
            
            axWindowsMediaPlayer1.URL = url;
            playerNum = num;
            
            updateNowPlayingData(false, false, num);

            updateRecentlyPlayedBox();
        }

        private void axWindowsMediaPlayer1_StatusChange(object sender, EventArgs e)
        {
            if (axWindowsMediaPlayer1.playState != WMPLib.WMPPlayState.wmppsReady //&&
                //axWindowsMediaPlayer1.playState != WMPLib.WMPPlayState.wmppsStopped
                )
            {
                String status = axWindowsMediaPlayer1.status;
                if (status.Contains("Playing"))
                {
                    String[] temp = status.Replace("reflector:", "").Split(':');
                    status = "Playing (" + temp[1].Trim() + ")";
                }
                pLabel5.Visible = true;
                pLabel5.Text = status;
                if (status.Equals("") == false)
                {
                    if (playerNum != 0)
                    {
                        output("Player (" + self.Find(playerNum).ShortName + "): " + status, "player");
                    }
                    else
                    {
                        output("Player: " + status, "player");
                    }
                }
            }
        }

        private void axWindowsMediaPlayer1_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            output("Player ("+self.Find(playerNum).ShortName+"): " + axWindowsMediaPlayer1.playState, "player-debug");

            // If Windows Media Player is in the playing state, enable the data update timer. 
            if (axWindowsMediaPlayer1.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                pRetryTimer.Enabled = false;
                axWindowsMediaPlayer1.enableContextMenu = true;
                pTimer.Enabled = true;
                self.lastChannelPlayed = playerNum;

                showWMPPlayerUI();
            }
            else
            {
                pTimer.Enabled = false;
            }

            if (axWindowsMediaPlayer1.playState == WMPLib.WMPPlayState.wmppsStopped ||
                axWindowsMediaPlayer1.playState == WMPLib.WMPPlayState.wmppsReady)
            {
                axWindowsMediaPlayer1.enableContextMenu = false;
                //Save number when going to ready to restore on resume from sleep
                if (axWindowsMediaPlayer1.playState == WMPLib.WMPPlayState.wmppsReady)
                {
                    sleepPlayerNum = playerNum;
                }
                //Tell the app we're done playing so history stops being built.
                playerNum = 0;
                self.lastChannelPlayed = 0;
                updateNowPlayingData(true, false, 0);
            }

        }

        private void pTimer_Tick(object sender, EventArgs e)
        {
            updateNowPlayingData(false, false, 0);
        }

        private void pLabel2_TextChanged(object sender, EventArgs e)
        {
            if (pLabel2.Text.Equals("Title:") || pLabel2.Text.Equals(""))
            {
                return;
            }
            self.lastChannelPlayed = playerNum;
            updateRecentlyPlayedBox();
            doNotification();
            updateChannels();
        }

        private void doNotification()
        {
            if (playerNum == 0 || !showNotification) { return; } //Bail early if we have no work to do.
            XMChannel npChannel = self.Find(playerNum);
            String title = npChannel.ToString();
            String nptext = npChannel.artist + " - " + npChannel.song;
            NotifyWindow nw = new NotifyWindow(title, "Now Playing:\n" + nptext);
            nw.TitleFont = new Font("Tahoma", 8.25F, FontStyle.Bold);
            nw.Font = new Font("Tahoma", 10F);
            nw.TextColor = Color.White;
            nw.BackColor = Color.Black;
            nw.SetDimensions(300, 120);
            nw.WaitTime = 5000;
            nw.Notify();
        }

        private void initPlayer()
        {
            showLogo();
            axWindowsMediaPlayer1.uiMode = "none";

            pLabel5.Visible = false;
            updateNowPlayingData(true, false, 0);

            syncStatusLabel();

        }

        private void showLogo()
        {
            Image xmtunerLogo = Image.FromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("XMTuner.xmtuner64.png"));
            pLogoBox.ClientSize = new Size(64, 64);
            pLogoBox.Image = xmtunerLogo;
        }

        private void axWindowsMediaPlayer1_MouseMoveEvent(object sender, AxWMPLib._WMPOCXEvents_MouseMoveEvent e)
        {
            if (axWindowsMediaPlayer1.uiMode.Equals("mini") || axWindowsMediaPlayer1.playState != WMPLib.WMPPlayState.wmppsPlaying)
            {
                return;
            }
            showWMPPlayerUI();
        }

        private void showWMPPlayerUI()
        {
            axWindowsMediaPlayer1.uiMode = "mini";
            axWindowsMediaPlayer1.Size = new Size(165, 35);
            pHoverTimer.Start();
        }

        private void pHoverTimer_Tick(object sender, EventArgs e)
        {
            pHoverTimer.Stop();
            axWindowsMediaPlayer1.uiMode = "none";
            axWindowsMediaPlayer1.Size = new Size(165, 50);
        }

        private void shutdownPlayer()
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();
        }

        private void axWindowsMediaPlayer1_ErrorEvent(object sender, EventArgs e)
        {
            // Get the description of the first error. 
            int errCode = axWindowsMediaPlayer1.Error.get_Item(0).errorCode;
            string errDesc = axWindowsMediaPlayer1.Error.get_Item(0).errorDescription;

            // Display the error description.
            output(errCode + " " +errDesc, "error");

            //Handle things like stopping and trying to retune...
            int cnum = playerNum;
            axWindowsMediaPlayer1.Ctlcontrols.stop();
            pLabel1.Text = "Error!";
            pLabel2.Text = "A problem occured while playing your channel.";
            pLabel3.Text = "Attempting to retune (in 10 seconds)...";
            pLabel4.Text = errDesc;
            pStatusLabel.Text = "";
            output("Error! Attempting to retune channel "+self.Find(cnum).ToString()+" (in 10 seconds)...", "error");
            pRetryTimer.Tag = cnum;
            pRetryTimer.Start();
        }

        private void pRetryTimer_Tick(object sender, EventArgs e)
        {
            int cnum = (int)pRetryTimer.Tag;
            output("Attempting to retune to channel " + self.Find(cnum).ToString() + "...", "info");
            play(cnum);
        }

        #endregion
    }

}