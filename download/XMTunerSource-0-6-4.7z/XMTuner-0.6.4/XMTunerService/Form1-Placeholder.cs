﻿using System;
using System.Windows.Forms;

namespace XMTuner
{
    class Form1
    {
        public static void output(String output, String level, ref RichTextBox outputbox)
        {

        }

        public static Boolean isService
        {
            get
            {
                return true;
            }
        }
    }
}
